<template>

	<div class="column is-full-mobile is-half-tablet is-one-third-desktop">
		<div class="card">
		  <div class="card-content">
		    <div class="media">
		    </div>
		  </div>
		</div>
	</div>
	
</template>

<script>
	export default {
		props: [],

		computed: {

			
		},

		methods: {
    
            
    	}

	}
</script>

<style>

	
	
</style>