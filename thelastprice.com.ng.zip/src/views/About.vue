<template>

	<div class="content-padding">
	<section class="hero">
    <div class="hero-body">
      <h1 class="title is-3 has-text-centered"><strong><span class="blue-text">About</span></strong></h1>
    </div>
</section>
  <div class="is-mobile columns">
  <div class="box column is-10 is-offset-1 is-lastprice">
      <p class="subtitle has-text-white">jhefhjrehejrjherhjerhjerhjerherjhhjhcjhd</p>
</div>
<div class="column"></div>
</div>
</div>
	
</template>

<script>
	export default {
		data() {
			return {

			}
		}
	}
</script>

<style>	

</style>