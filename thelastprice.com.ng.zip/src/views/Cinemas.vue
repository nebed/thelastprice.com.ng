<template>
	
	<div class="content-padding">
	<section class="hero">
    <div class="hero-body">
      <h1 class="title is-3 has-text-centered"><strong><span class="blue-text">Cinema </span><span class="orange-text">Prices</span></strong></h1>
    </div>
</section>
<div class="is-mobile columns">
  <div class="box column is-10 is-offset-1 is-lastprice">
      <p>jhefhjrehejrjherhjerhjerhjerherjhhjhcjhd</p>
</div>
<div class="column"></div>
</div>
</div>

</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style type="text/css">
	
</style>